<?php
header("Location: index.php?page=login");
exit;
?>