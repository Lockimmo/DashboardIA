<h2>Contact</h2>
<p>Pour nous contacter, envoyez un email à <a href="mailto:contact@projetia.test">contact@projetia.test</a>.</p>
