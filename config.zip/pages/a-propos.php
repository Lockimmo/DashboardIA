<h2>À propos</h2>
<p>Ce projet a pour but d'expérimenter un site PHP simple avant d'y intégrer des fonctionnalités avancées comme la base de données ou l'authentification.</p>
