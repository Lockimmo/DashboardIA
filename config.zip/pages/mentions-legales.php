<h2>Mentions légales</h2>
<p>Ce site est un projet pédagogique fictif développé dans le cadre d'un apprentissage PHP.</p>
